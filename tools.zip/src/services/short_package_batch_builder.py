from src.models.final_highlight import FinalHighlight
from src.models.recording_session import RecordingSession
from src.models.short_package import ShortPackage
from src.services.facecam_short_renderer import FaceCamShortRenderer
from src.services.short_package_builder import ShortPackageBuilder


class ShortPackageBatchBuilder:
    """Build complete Short packages for all approved highlights."""

    def __init__(
        self,
        builder: ShortPackageBuilder | None = None,
        facecam_renderer: FaceCamShortRenderer | None = None,
    ) -> None:
        self.builder = (
            builder
            if builder is not None
            else ShortPackageBuilder()
        )

        self.facecam_renderer = (
            facecam_renderer
            if facecam_renderer is not None
            else FaceCamShortRenderer()
        )

    def build(
        self,
        highlights: list[FinalHighlight],
        output_folder: str,
        recording_session: RecordingSession | None = None,
        layout_type: str | None = None,
    ) -> list[ShortPackage]:
        resolved_layout_type = layout_type or "portrait"

        if recording_session is not None:
            if recording_session.has_facecam_layout:
                self.facecam_renderer.validate(recording_session)
                resolved_layout_type = "face_top"
            else:
                resolved_layout_type = "portrait"

        packages: list[ShortPackage] = []

        for highlight in highlights:
            package = self.builder.build(
                highlight=highlight,
                output_folder=output_folder,
                layout_type=resolved_layout_type,
                recording_session=recording_session,
            )

            packages.append(package)

        return packages